namespace Codenation.Challenge
{
    public interface ICrypt     
	{
		string Crypt(string message);
	}
}