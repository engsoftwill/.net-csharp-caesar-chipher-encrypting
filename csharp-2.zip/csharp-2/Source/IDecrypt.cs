namespace Codenation.Challenge
{
    public interface IDecrypt 
	{
		string Decrypt(string cryptedMessage);
	}
}